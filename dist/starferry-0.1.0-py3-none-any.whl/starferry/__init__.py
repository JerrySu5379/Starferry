"""Starferry - FastAPI-based API service for AI generation."""

__version__ = "0.1.0"
